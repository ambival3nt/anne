<div>
    <button wire:click="testBotClick()">Don't Push</button>
</div>
